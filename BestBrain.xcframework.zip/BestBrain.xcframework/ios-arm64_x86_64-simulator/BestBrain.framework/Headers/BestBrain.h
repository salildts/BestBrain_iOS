//
//  BestBrain.h
//  BestBrain
//
//  Created by Mithun Bera on 12/09/24.
//

#import <Foundation/Foundation.h>

//! Project version number for BestBrain.
FOUNDATION_EXPORT double BestBrainVersionNumber;

//! Project version string for BestBrain.
FOUNDATION_EXPORT const unsigned char BestBrainVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BestBrain/PublicHeader.h>


